#include<string>
#include<iostream>
#include<cstring>

using namespace std;

int main () 
{
    char cadena[1000];
    cout << "Ingrese una palabra: ";
    cin>> cadena;
    int i=0;
    int c=1;
    int len= strlen(cadena);
    while(i<len)
    {
        if (cadena[i]==cadena[len-c])
        {
            i=i+1;
            c=c+1;
        }
        else
        {
            cout << "La palabra " << cadena << " no es una palabra Palindromo" <<endl;
            i=len;
            return 0;
            
        }
    }
    cout << "La palabra " << cadena << " es una palabra Palindromo" <<endl;
}
    
