#include <iostream>
using namespace std;

void Hanoi (int n, char p1, char p3, char p2)
{
    if (n==1) 
    {
        cout<< "Mover el disco del poste " << p1 << " al poste " << p3 <<endl; 
    }
    else
    {
        Hanoi ( n-1, p1, p2, p3);
        cout<< "Mover el disco del poste "<< p1 <<" al poste " << p3 <<endl;
        Hanoi ( n-1, p2, p3, p1);
    }

}

int main () 
{


    int n;
    cout << "Ingrese un numero: "<<endl;
    cin >> n;

    Hanoi (n, '1', '2', '3');
    
}


