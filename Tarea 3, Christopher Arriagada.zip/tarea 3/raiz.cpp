#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int Raiz(double n, float err)
{   
    double raiz;
    raiz= n - (((pow(n,2))-2)/(2*n));
    double p=abs(n-raiz);
    if (p>=err)
    {   
        Raiz(raiz,err);
    }
    else
    { 
        cout.precision(7);
        cout<< " La raiz de 2 es " << raiz<<" con una presicion de " << err <<endl;
    }
    return 0;
}

int main () 
{
    double n=2;
    double err=pow(10,-6);

    Raiz (n, err);
}