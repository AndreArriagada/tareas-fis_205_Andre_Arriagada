#include <iostream>
#include <cmath>
using namespace std;

int main(){
    //Se definen los tipos de variables
    float beta,g1,g2; //g1, se refiere al cálculo de gamma con el factor beta, g2 se refiere al càlculo de gamma con el factor epsilon
    int i=1;
    float err=pow(10,-5);
    while (err<pow(10,-3)){
        float beta=1-(1*pow(10,-i));//Se define el valor de beta como 0.9,0.99,0.999 ...
        float eps=1*pow(10,-i); //Se define el valor de beta como 0.1,0.01,0.001 ...
        i=i+1;
        float g1=1/sqrt(1-pow(beta,2)); //Valor teorico de gamma
        float g2=1/sqrt((2-eps)*eps); //Valor experimental
        err=abs(g1-g2)/g1;//Corresponde al error

        //Se imprimen los valores para el error y el calculo de gamma con ambas fórmulas
        cout<< "El valor de error es: " << err << endl;
        cout<< "El valor de g1 es: " << g1 <<endl;
        cout<< "El valor de g2 es: " << g2 <<endl;
        cout<< "El valor de Beta es: " << beta <<endl;
     
        if (err>=pow(10,-3)){
        cout<< "El valor de maximo de Beta es: " << beta <<endl;

        } 
        
    }
        
}
//Cabe mencionar que el enunciado de la pregunta se entiende que el error puede ser a lo mas 0.001, por ello va aumentando el error 
