//Se integran las funciones necesarias
#include <iostream>
#include <vector>
using namespace std;

//Definicion de la clase Polinomio
class Polinomio {
private:
    int grado;
public:
    //Constructor que toma el grado del polinomio
    Polinomio(int grado_) : grado(grado_) {}// Se inicializa el constructor de manera uniforme
    vector<double> numeros; // Definicion del vector numeros con datos tipos double para los coeficientes
    void coeficientes(); //Definición de la funcion donde se guardan los coeficientes
    
    //Función para obtener el grado del polinomio, se define dentro de la clase
    int obtgrado() const {
        return grado;
    }

    //Sobrecarga del operador de inserción de flujo
    friend ostream& operator<<(ostream& os, const Polinomio& p);

    //Se define el destructor
    ~Polinomio() {}

};

// Se define la función para obtener los coeficientes en un vector
void Polinomio::coeficientes(){
    int i=0;
    double coef;
    
    while(i<=grado){
        cout << "Ingrese el coeficiente x^" << i << ": ";
        cin >> coef;
        numeros.push_back(coef);//Se agrega cada coeficiente coef al vector numeros
        i =i+1;
    }
    
}

//Definición de la función de sobrecarga del operador de inserción de flujo que imprime desde la clase
ostream& operator<<(ostream& os, const Polinomio& p) {
    os << "P(x)= ";
    //Se recorre con ii los elementos, el contador ii sirve para indicar el indice del vector numeros 
    for (int ii=p.obtgrado(); ii >= 0; ii=ii-1) {//Primero se iguala al grado del polinomio, luego se va disminuyendo el contador para ir descontando el grado
        if (ii==p.obtgrado()) {//Primer coeficiente que acompaña al x de mayor grado
            os << p.numeros[ii] << "x^" << ii << " ";
        // Condición para escribir coeficientes positivos y negativos
        } else if (p.numeros[ii] >= 0) {
            os << "+ " << p.numeros[ii] << "x^" << ii << " ";
        } else {
            os << "- " << -p.numeros[ii] << "x^" << ii << " ";
        }
    }
    return os;
}

int main() {
    int grado;
    cout << "Ingrese el grado del polinomio: ";
    cin >> grado;
    //Llama a clase Polinomio otorgando el valor de grado y la funcion coefieintes
    Polinomio p(grado);
    p.coeficientes();
    //Impresión del polinomio utilizando la sobrecarga del operador de inserción de flujo
    cout << p << endl;
    
    return 0;
}