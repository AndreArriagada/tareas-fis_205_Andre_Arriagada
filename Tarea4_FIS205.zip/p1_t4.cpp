#include <iostream>
using namespace std;

class Vector{
    //Definicion del tipo de variables para los miembros
    int escalar;
    float x1,y1,z1,x2,y2,z2;
    
    public:
        //Constructor, contiene los componentes de cada vector, inicializado de manera uniforme
        Vector(int e,float _x1,float _y1,float _z1,float _x2,float _y2,float _z2){escalar=e; x1=_x1;y1=_y1;z1=_z1;x2=_x2;y2=_y2;z2=_z2;} 
        //Se definen como miembros de la clase las funciones requeridas
        void multiplicacion();
        void suma();
        void productopunto();
        void productocruz();

};

//Definimos las funciones miembros de la clase vector:

//Se define la funcion multiplicación por escalar para los vectores ingresados
void Vector::multiplicacion(){
    float mx1=escalar*x1;
    float my1=escalar*y1;
    float mz1=escalar*z1;
    float mx2=escalar*x2;
    float my2=escalar*y2;
    float mz2=escalar*z2;
    cout<<"La multiplicación por escalar del primer vector es: ( "<<mx1<<" , "<<my1<<" , "<<mz1<<" )"<<endl;
    cout<<"La multiplicación por escalar del primer vector es: ( "<< mx2 <<" , "<< my2 <<" , "<< mz2 <<" )"<<endl;
    
}

//Se define la funcion para la suma de vectores
void Vector::suma() {
    float sx=x1+x2;
    float sy=y1+y2;
    float sz=z1+z2;
    cout<< "La suma de los vectores es: ( "<< sx <<" , " << sy <<" , "<< sz<< " )" <<endl;
    
}
//Se define la funcion de producto punto 
void Vector::productopunto() {
    float px=x1*x2;
    float py=y1*y2;
    float pz=z1*z2;
    float result=px+py+pz;
    cout<< "El producto punto entre vectores es: "<< result << endl;
    
}
//Se define la funcion de producto cruz
void Vector::productocruz() {
    float cx=(y1*z2)-(z1*y2);
    float cy=(z1*x2)-(x1*z2);
    float cz=(x1*y2)-(y1*x2);
    cout<< "El producto cruz entre vectores es: ( "<< cx <<" , " << cy <<" , "<< cz << " )" <<endl;
    
}

int main(){
    int escalar;
    float x_1, y_1, z_1, x_2, y_2, z_2;
    //Se ingresan de los valores de los componentes de cada vector y del escalar
    cout << "Ingrese el numero para el escalar: ";
    cin >> escalar;
    //Se deben ingresar los componentes del numero separados por un espacio y sin parentesis
    cout << "Ingrese los componentes para el vector 1, en el siguiente formato; x y z : ";
    cin >> x_1 >> y_1 >> z_1;
    cout << "Ingrese los componentes para el vector 2, en el siguiente formato; x y z : ";
    cin >> x_2 >> y_2 >> z_2;
    //Creamos el objeto de la clase Vectos y llamamos al constructor (que corresponde a ambos vectores en un solo elemento)
    Vector v (escalar,x_1,y_1,z_1,x_2,y_2,z_2);
    //Llamamos a la funcion correspondiente a los miembros de la clase para que se evalue el objeto v
    v.multiplicacion();
    v.suma();
    v.productopunto();
    v.productocruz();
    return 0;
}